export default class Recipe {
    name: string;
    ingredients: string[];
    steps: string;
}