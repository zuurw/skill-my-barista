'use strict';

export const SUGGESTION_RECETTE_INTENT = 'SuggestionRecetteIntent';
export const RECETTE_SPECIFIQUE_INTENT = 'RecetteSpecifiqueIntent';
export const NOMBRE_RECETTE_INTENT = 'NombreRecetteIntent';